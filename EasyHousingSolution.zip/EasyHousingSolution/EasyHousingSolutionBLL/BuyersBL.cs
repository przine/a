﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
    public class BuyersBL
    {
        BuyersDAL buyersDAL = new BuyersDAL();
        public bool AddBuyerBL(Buyer newBuyer)
        {
            bool BuyerAdded = false;
            try
            {
                //if (ValidateBuyer(newBuyer))
                //{
                BuyerAdded = buyersDAL.AddBuyerDAL(newBuyer);
                //}
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return BuyerAdded;
        }

        public List<Buyer> GetAllBuyersBL()
        {
            try
            {
                List<Buyer> BuyerList = null;
                try
                {
                    BuyerList = buyersDAL.GetAllBuyersDAL();
                }
                catch (EasyHousingSolutionException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return BuyerList;
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

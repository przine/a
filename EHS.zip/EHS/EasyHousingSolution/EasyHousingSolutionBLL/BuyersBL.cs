﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
    public class BuyersBL
    {
        BuyersDAL buyersDAL = new BuyersDAL();
        protected bool ValidateBuyers(Buyer buyersToValidate)
        {
            StringBuilder sb = new StringBuilder();

            bool validatebuyers = true;

            if (buyersToValidate.BuyerId.ToString().Length == 0)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "Buyer Id Required");
            }
            if (buyersToValidate.FirstName == string.Empty)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "FirstName Required");
            }
            if (buyersToValidate.LastName == string.Empty)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "Last Name required");
            }
            if (buyersToValidate.DateOfBirth.ToString() == string.Empty)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "dob required");
            }
            if (buyersToValidate.PhoneNo.ToString() == string.Empty)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "PhoneNumber Required");
            }
            if (buyersToValidate.EmailId.ToString() == string.Empty)
            {
                validatebuyers = false;
                sb.Append(Environment.NewLine + "Email Required");
            }
            if (validatebuyers == false)
                throw new EHSException.EasyHousingSolutionException(sb.ToString());
            return validatebuyers;


        }
        public bool AddBuyerBL(Buyer newBuyer)
        {
            bool BuyerAdded = false;
            try
            {
                if (ValidateBuyers(newBuyer))
                {
                BuyerAdded = buyersDAL.AddBuyerDAL(newBuyer);
                }
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return BuyerAdded;
        }

        public List<Buyer> GetAllBuyersBL()
        {
            try
            {
                List<Buyer> BuyerList = null;
                try
                {
                    BuyerList = buyersDAL.GetAllBuyersDAL();
                }
                catch (EasyHousingSolutionException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return BuyerList;
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

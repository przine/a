﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EasyHousingSolutionPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            AddProperty cw = new AddProperty();           
            cw.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string uname=Application.Current.Properties["username"].ToString();
           
            if(uname.Equals("Seller"))
            {              
                addMenu.Visibility = Visibility.Visible;
                editMenu.Visibility = Visibility.Visible;
                viewMenu.Visibility = Visibility.Visible;
               
            }
            else if (uname == "Admin")
            {                
                viewMenu.Visibility = Visibility.Visible;
                verifyMenu.Visibility = Visibility.Visible;
                deleteMenu.Visibility = Visibility.Visible;
            }
            else if (uname == "Buyer")
            {
                searchMenu.Visibility = Visibility.Visible;
                cartMenu.Visibility = Visibility.Visible;
            }
        }

        private void addSubmenu_Click(object sender, RoutedEventArgs e)
        {
            AddProperty obj = new AddProperty();
            this.Hide();
            obj.Show();
        }

        private void uploadImgSubmenu_Click(object sender, RoutedEventArgs e)
        {
            UploadImage obj = new UploadImage();
            this.Hide();
            obj.Show();
        }

        private void editMenu_Click(object sender, RoutedEventArgs e)
        {
            EditProperty obj = new EditProperty();
            this.Hide();
            obj.Show();
        }

        private void viewVerifiedSubmenu_Click(object sender, RoutedEventArgs e)
        {
            ViewVerifiedProperty obj = new ViewVerifiedProperty();
            this.Hide();
            obj.Show();
        }

        private void viewDeactSubmenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void viewRegionSubmenu_Click(object sender, RoutedEventArgs e)
        {
            ViewPropertyByRegion obj = new ViewPropertyByRegion();
            this.Hide();
            obj.Show();
        }

        private void viewOwnerSubmenu_Click(object sender, RoutedEventArgs e)
        {
            ViewPropertyByOwner obj = new ViewPropertyByOwner();
            this.Hide();
            obj.Show();
        }

        private void viewDetailsSubmenu_Click(object sender, RoutedEventArgs e)
        {
            ViewProperty obj = new ViewProperty();
            this.Hide();
            obj.Show();
        }

        private void searchMenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void deleteMenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void verifyMenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void cartMenu_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
    public class PropertyBL
    {
        PropertyDAL propertyDAL = new PropertyDAL();

        public bool AddPropertyBL(Property newProperty)
        {
            bool PropertyAdded = false;
            try
            {
                //if (ValidateProperty(newProperty))
                //{

                PropertyAdded = propertyDAL.AddPropertyDAL(newProperty);
                //}
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PropertyAdded;
        }

        public List<Property> GetAllPropertyByOwnerBL(string SellerName)
        {
            List<Property> PropertyList = null;
            try
            {
                PropertyList = propertyDAL.GetPropertyByOwnerDAL(SellerName);
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PropertyList;
        }

        public List<Property> GetAllPropertyByRegionBL(string CityName)
        {
            List<Property> PropertyList = null;
            try
            {
                PropertyList = propertyDAL.GetPropertyByRegionDAL(CityName);
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PropertyList;
        }

        public List<Property> GetVerifiedPropertyBL()
        {
            List<Property> PropertyList = null;
            try
            {
                PropertyList = propertyDAL.GetVerifiedPropertyDAL();
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PropertyList;
        }

        public List<Property> GetAllPropertyBL()
        {
            List<Property> PropertyList = null;
            try
            {
                PropertyList = propertyDAL.GetAllPropertyDAL();
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PropertyList;
        }

        //public bool DeletePropertyBL(int deletePropertyID)
        //{
        //    bool PropertyDeleted = false;
        //    try
        //    {
        //        if (deletePropertyID > 0)
        //        {
        //            PropertyDeleted = propertyDAL.DeletePropertyDAL(deletePropertyID);
        //        }
        //        else
        //        {
        //            throw new EasyHousingSolutionException("Invalid Property ID");
        //        }
        //    }
        //    catch (EasyHousingSolutionException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return PropertyDeleted;
        //}

        public Property SearchPropertyBL(int searchPropertyID)
        {
            Property searchProperty = null;
            try
            {
                searchProperty = propertyDAL.SearchPropertyDAL(searchPropertyID);
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchProperty;

        }

        public bool EditPropertyBL(Property updateProperty)
        {
            bool PropertyUpdated = false;
            try
            {
                //if (ValidateProperty(updateProperty))
               // {
                    PropertyUpdated = propertyDAL.EditPropertyDAL(updateProperty);
               // }
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PropertyUpdated;
        }

    }
}

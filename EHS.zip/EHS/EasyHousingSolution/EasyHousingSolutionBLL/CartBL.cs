﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
    public class CartBL
    {
        CartDAL cartDAL = new CartDAL();
        public bool AddCartBL(Cart newCart)
        {
            bool CartAdded = false;
            try
            {
                //if (ValidateCart(newCart))
                //{

                CartAdded = cartDAL.AddCartDAL(newCart);
                //}
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CartAdded;
        }

        public List<Cart> GetAllCartsBL()
        {
            List<Cart> CartList = null;
            try
            {
                CartList = cartDAL.GetAllCartDAL();
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CartList;
        }
        public bool DeleteCartBL(int deleteCartID)
        {
            bool CartDeleted = false;
            try
            {
                if (deleteCartID > 0)
                {
                    CartDeleted = cartDAL.DeleteCartDAL(deleteCartID);
                }
                else
                {
                    throw new EasyHousingSolutionException("Invalid Cart ID");
                }
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CartDeleted;
        }
    }
}

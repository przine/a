﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasyHousingSolutionEntity;
using EHSException;
using EasyHousingSolutionBLL;

namespace EasyHousingSolutionPL
{
    /// <summary>
    /// Interaction logic for ViewProperty.xaml
    /// </summary>
    public partial class ViewProperty : Window
    {
        PropertyBL propertyBL = new PropertyBL();
        CartBL cartBL = new CartBL();
       EasyHousingSolutionEntity.Cart addCart = new EasyHousingSolutionEntity.Cart();
        string BuyerName = null;


        public ViewProperty()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                BuyerName = Application.Current.Properties["BuyerName"].ToString();
                dgViewAllData.DataContext = propertyBL.GetAllPropertyBL();
            }
            catch (EasyHousingSolutionException ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        private void btnShow_details_Click(object sender, RoutedEventArgs e)
        {
            Property property = (Property)dgViewAllData.SelectedItem;           
            addCart.PropertyId= property.PropertyId;
            txtPropName.Text = property.PropertyName;
            txtPropType.Text = property.PropertyType;
            txtPrice.Text = property.PriceRange.ToString();
            txtLandmark.Text = property.Landmark;
            txtAddress.Text = property.Address;
            txtSeller.Text = property.SellerId.ToString();
            txtInitialDeposit.Text = property.InitialDeposit.ToString();
            txtDes.Text = property.Description;
        }

        private void btnAddToCart_Click(object sender, RoutedEventArgs e)
        {
           // int id=getBuyerId(BuyerName);
           if(cartBL.AddCartBL(addCart))
            {
                MessageBox.Show("Product added to cart...");
            }
            else{
                MessageBox.Show("Failed to add to cart");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionEntity;
using System.Data;
using System.Data.SqlClient;
using EHSException;

namespace EasyHousingSolutionDAL
{
  public class UsersDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);
        public bool AddUserDAL(Users newUser)
        {
            bool UserAdded = false;
            try
            {
                string Query = "EHS.AddUser";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@UserName", newUser.UserName);
                command.Parameters.AddWithValue("@UserType", newUser.UserType);
                command.Parameters.AddWithValue("@Password", newUser.Password);
               
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                UserAdded = true;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return UserAdded;
        }

        //public List<Users> GetAllUsersDAL()
        //{
        //    List<User> UserList = new List<User>();
        //    string Query = "EHS.GetUser";
        //    SqlCommand command = new SqlCommand(Query, connection);
        //    command.CommandType = CommandType.StoredProcedure;
        //    connection.Open();
        //    SqlDataReader Reader = command.ExecuteReader();
        //    if (Reader.HasRows)
        //    {
        //        while (Reader.Read())
        //        {
        //            User s = new User();
        //            s.UserId = int.Parse(Reader[0].ToString());
        //            s.UserName = Reader[1].ToString();
        //            s.FirstName = Reader[2].ToString();
        //            s.LastName = Reader[3].ToString();
        //            s.DateofBirth = DateTime.Parse(Reader[4].ToString());
        //            s.PhoneNo = long.Parse(Reader[5].ToString());
        //            s.Address = Reader[6].ToString();
        //            s.StateId = int.Parse(Reader[7].ToString());
        //            s.CityId = int.Parse(Reader[8].ToString());
        //            s.EmailId = Reader[9].ToString();
        //            UserList.Add(s);
        //        }
        //    }
        //    connection.Close();
        //    return UserList;

        //}

        public bool getUserPassword(Users user)
        {
            bool IsPasswordMatch = false;
            try
            {
                SqlCommand command = new SqlCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "EHS.GetPassword";
                command.Parameters.AddWithValue("@UserName", user.UserName);
                command.Parameters.AddWithValue("@UserType", user.UserType);
                command.Connection = connection;
                connection.Open();
                object retrievePassword = command.ExecuteScalar().ToString();
                IsPasswordMatch = false;
                if (retrievePassword != null && user.Password == retrievePassword.ToString())
                {
                    IsPasswordMatch = true;
                }
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return IsPasswordMatch;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasyHousingSolutionEntity;
using EHSException;
using EasyHousingSolutionBLL;
namespace EasyHousingSolutionPL
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        SellersBL sellersBLL = new SellersBL();
        BuyersBL buyersBL = new BuyersBL();
        UserBL userBL = new UserBL();
        public Registration()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Users newUser = new Users();
                newUser.UserName = txtUsername.Text;
                newUser.Password = pbPassword.Password.ToString();
                newUser.UserType = cbUsertype.Text;

                if (newUser.UserType == "Buyer")
                {
                    Application.Current.Properties["username"] = newUser.UserType;
                    userBL.AddUserBL(newUser);

                    Buyer buyer = new Buyer();
                    buyer.UserName = txtUsername.Text;
                    buyer.FirstName = txtFirstname.Text;
                    buyer.LastName = txtLastname.Text;
                    buyer.DateOfBirth = DateTime.Parse(dpDob.Text.ToString());
                    buyer.PhoneNo = long.Parse(txtPhone.Text);
                    buyer.EmailId = txtUsername.Text;
                    if (buyersBL.AddBuyerBL(buyer))
                    {
                        MessageBox.Show("Registered successfully....");
                        Login obj = new Login();
                        this.Hide();
                        obj.Show();
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong...");
                    }

                }
                else if (newUser.UserType == "Seller")
                {
                    Application.Current.Properties["username"] = newUser.UserType;
                    userBL.AddUserBL(newUser);

                    Seller seller = new Seller();
                    seller.UserName = txtUsername.Text;
                    seller.FirstName = txtFirstname.Text;
                    seller.LastName = txtLastname.Text;
                    seller.DateofBirth = DateTime.Parse(dpDob.Text.ToString());
                    seller.PhoneNo = long.Parse(txtPhone.Text);
                    seller.Address = txtAddress.Text;
                    seller.StateName = cbStates.Text;
                    seller.CityName = cbCities.Text;
                    seller.EmailId = txtUsername.Text;
                    if (sellersBLL.AddSellerBL(seller))
                    {
                        MessageBox.Show("Registered successfully....");
                        Login obj = new Login();
                        this.Hide();
                        obj.Show();
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong...");
                    }

                }

            }
            catch (EasyHousingSolutionException ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        private void cbStates_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                cbCities.Items.Clear();
                cbCities.Items.Add("Select");
                string stateName = cbStates.SelectedItem.ToString().Split(new string[] { ": " }, StringSplitOptions.None).Last();

                if (stateName.Equals("Telangana"))
                {
                    cbCities.Items.Add("Hyderabad");
                    cbCities.Items.Add("Nizamabad");
                }
                else if (stateName.Equals("Maharashtra"))
                {
                    cbCities.Items.Add("Mumbai");
                    cbCities.Items.Add("Pune");
                }
                else if (stateName.Equals("Andhra Pradesh"))
                {
                    cbCities.Items.Add("Visakhapatnam");
                    cbCities.Items.Add("Vijayawada");
                }
                else if (stateName.Equals("Karnataka"))
                {
                    cbCities.Items.Add("Bangalore");
                    cbCities.Items.Add("Mysore");
                }
            }          
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        private void cbUsertype_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string userType = cbUsertype.SelectedItem.ToString().Split(new string[] { ": " }, StringSplitOptions.None).Last();
                if (userType.Equals("Seller"))
                {
                    txtAddress.IsEnabled = true;
                    cbStates.IsEnabled = true;
                    cbCities.IsEnabled = true;
                }
                else if (userType.Equals("Buyer"))
                {
                    txtAddress.IsEnabled = false;
                    cbStates.IsEnabled = false;
                    cbCities.IsEnabled = false;
                }
            }           
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }
    }
}

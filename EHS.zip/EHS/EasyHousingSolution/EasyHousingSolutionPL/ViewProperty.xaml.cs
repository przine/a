﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasyHousingSolutionEntity;
using EHSException;
using EasyHousingSolutionBLL;

namespace EasyHousingSolutionPL
{
    /// <summary>
    /// Interaction logic for ViewProperty.xaml
    /// </summary>
    public partial class ViewProperty : Window
    {
        PropertyBL propertyBL = new PropertyBL();
        public ViewProperty()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                dgViewAllData.DataContext = propertyBL.GetAllPropertyBL();
            }
            catch (EasyHousingSolutionException ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        private void btnShow_details_Click(object sender, RoutedEventArgs e)
        {
            Property property = (Property)dgViewAllData.SelectedItem;
            txtPropName.Text = property.PropertyName;
            txtPropType.Text = property.PropertyType;
            txtPrice.Text = property.PriceRange.ToString();
            txtLandmark.Text = property.Landmark;
            txtAddress.Text = property.Address;
            txtSeller.Text = property.SellerId.ToString();
            txtInitialDeposit.Text = property.InitialDeposit.ToString();
            txtDes.Text = property.Description;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
   public class UserBL
    {
        UsersDAL usersDAL = new UsersDAL();
        public bool AddUserBL(Users newUser)
        {
            bool UserAdded = false;
            try
            {
                //if (ValidateSeller(newSeller))
                //{
                UserAdded = usersDAL.AddUserDAL(newUser);
                //}
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return UserAdded;
        }
        public bool getPasswordBLL(Users user)
        {
            bool IsUserValid = false;
            try
            {
                IsUserValid = usersDAL.getUserPassword(user);
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return IsUserValid;
        }
    }
}

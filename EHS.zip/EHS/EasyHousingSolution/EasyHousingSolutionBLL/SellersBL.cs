﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionDAL;
using EasyHousingSolutionEntity;
using EHSException;

namespace EasyHousingSolutionBLL
{
    public class SellersBL
    {
        SellersDAL sellerDAL = new SellersDAL();
        public bool AddSellerBL(Seller newSeller)
        {
            bool SellerAdded = false;
            try
            {
                //if (ValidateSeller(newSeller))
                //{

                    SellerAdded = sellerDAL.AddSellerDAL(newSeller);
                //}
            }
            catch (EasyHousingSolutionException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return SellerAdded;
        }

        //public List<Seller> GetAllSellersBL()
        //{
        //    List<Seller> SellerList = null;
        //    try
        //    {
        //        SellerList = sellerDAL.GetAllSellersDAL();
        //    }
        //    catch (EasyHousingSolutionException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return SellerList;
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionEntity;
using System.Data;
using System.Data.SqlClient;
using EHSException;

namespace EasyHousingSolutionDAL
{
    public class CartDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);
        public bool AddCartDAL(Cart newCart)
        {
            bool CartAdded = false;
            try
            {
                string Query = "EHS.AddCart";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@BuyerId", newCart.BuyerId);
                command.Parameters.AddWithValue("@CartId", newCart.CartId);
               
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                CartAdded = true;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return CartAdded;
        }

        public List<Cart> GetAllCartDAL()
        {
            List<Cart> CartList = new List<Cart>();
            try
            {               
                string Query = "EHS.GetCart";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader Reader = command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        Cart s = new Cart();
                        s.CartId = int.Parse(Reader[0].ToString());
                        s.BuyerId = int.Parse(Reader[1].ToString());
                        s.PropertyId = int.Parse(Reader[2].ToString());

                        CartList.Add(s);
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return CartList;
            
        }
        public bool DeleteCartDAL(int deleteCartID)
        {
            bool CartDeleted = false;
            try
            {
                SqlCommand command = new SqlCommand("EHS.DeleteCart", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CartId", deleteCartID);
                connection.Open();
                int numberOfRowsDeleted = command.ExecuteNonQuery();
                if (numberOfRowsDeleted == 1)
                {
                    CartDeleted = true;
                }              
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return CartDeleted;

        }
    }
}

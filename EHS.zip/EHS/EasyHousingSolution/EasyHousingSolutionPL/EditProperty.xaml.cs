﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasyHousingSolutionBLL;
using EHSException;
using EasyHousingSolutionEntity;

namespace EasyHousingSolutionPL
{
    /// <summary>
    /// Interaction logic for EditProperty.xaml
    /// </summary>
    public partial class EditProperty : Window
    {
        EasyHousingSolutionBLL.PropertyBL propertyBL = new EasyHousingSolutionBLL.PropertyBL();

        public EditProperty()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchPropertyPL();

        }
        public void SearchPropertyPL()
        {
            try
            {
                int PropertyId = int.Parse(txtPropertyId.Text);
                Property searchProperty = propertyBL.SearchPropertyBL(PropertyId);
                if (searchProperty != null)
                {
                    MessageBox.Show("Record Found");
                    txtPropertyName.Text = searchProperty.PropertyName;
                    CbPropertyType.Text = searchProperty.PropertyType;
                    txtDescription.Text = searchProperty.Description;
                    txtAddress.Text = searchProperty.Address;
                    txtPriceRange.Text = searchProperty.PriceRange.ToString();
                    txtInitialDeposite.Text = searchProperty.InitialDeposit.ToString();
                    txtLandmark.Text = searchProperty.Landmark;
                    txtSellerId.Text = searchProperty.SellerId.ToString();
                }
                else
                {
                    MessageBox.Show("Record not Found");
                }
            }
            catch (EasyHousingSolutionException ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (EditPropertyPL())
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Failed to update student");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }
        public bool EditPropertyPL()
        {
            int PropertyId = int.Parse(txtPropertyId.Text);
            Property editProperty = propertyBL.SearchPropertyBL(PropertyId);
            bool PropertyEdited = false;
            try
            {
                if (editProperty != null)
                {
                    editProperty.PropertyId = int.Parse(txtPropertyId.Text);
                    editProperty.PropertyName = txtPropertyName.Text;

                    editProperty.PropertyType = CbPropertyType.Text;
                    editProperty.Description = txtDescription.Text;
                    editProperty.Address = txtAddress.Text;
                    editProperty.PriceRange = int.Parse(txtPriceRange.Text);
                    editProperty.InitialDeposit = int.Parse(txtInitialDeposite.Text);
                    editProperty.Landmark = txtLandmark.Text;
                    editProperty.SellerId = int.Parse(txtSellerId.Text);


                    PropertyEdited = propertyBL.EditPropertyBL(editProperty);

                }
            }
            catch (EasyHousingSolutionException ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
            return PropertyEdited;
        }
    }
}

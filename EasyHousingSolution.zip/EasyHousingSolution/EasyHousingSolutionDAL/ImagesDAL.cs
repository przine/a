﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EasyHousingSolutionEntity;
using System.Data;
using System.Data.SqlClient;
using EHSException;

using System.Threading.Tasks;

namespace EasyHousingSolutionDAL
{
    public class ImagesDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);

        public bool AddImageDAL(Images newImage)
        {
            bool ImageAdded = false;
            try
            {
                string Query = "EHS.AddImages";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@PropertyId", newImage.PropertyId);              
                command.Parameters.AddWithValue("@Image", newImage.Image);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                ImageAdded = true;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return ImageAdded;
        }
        public List<Images> GetAllImagesDAL()
        {
            try
            {
                List<Images> ImagesList = new List<Images>();
                string Query = "EHS.GetImages";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader Reader = command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        Images obj = new Images();
                        obj.ImageId = int.Parse(Reader[0].ToString());
                        obj.PropertyId = int.Parse(Reader[1].ToString());
                        obj.Image = Reader[2].ToString();

                        ImagesList.Add(obj);
                    }
                }
                connection.Close();
                return ImagesList;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}

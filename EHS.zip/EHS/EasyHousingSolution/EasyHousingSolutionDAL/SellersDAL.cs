﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionEntity;
using System.Data;
using System.Data.SqlClient;
using EHSException;


namespace EasyHousingSolutionDAL
{

    public class SellersDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);
        public int getStateId(string StateName)
        {
            try
            {
                int StateId = 0;
                string Query = "EHS.GetStateId";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StateName", StateName);
                connection.Open();
                object retrieveStateId = command.ExecuteScalar().ToString();
                StateId = int.Parse(retrieveStateId.ToString());
                connection.Close();
                return StateId;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public int getCityId(string CityName)
        {
            try
            {
                int CityId = 0;
                string Query = "EHS.GetCityId";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CityName", CityName);
                connection.Open();
                object retrieveCityId = command.ExecuteScalar().ToString();
                CityId = int.Parse(retrieveCityId.ToString());
                connection.Close();
                return CityId;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public bool AddSellerDAL(Seller newSeller)
        {
            bool SellerAdded = false;
            try
            {
                string Query = "EHS.AddSeller";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                
                command.Parameters.AddWithValue("@FirstName", newSeller.FirstName);
                command.Parameters.AddWithValue("@LastName", newSeller.LastName);
                command.Parameters.AddWithValue("@UserName", newSeller.UserName);
                command.Parameters.AddWithValue("@DateofBirth", newSeller.DateofBirth);
                command.Parameters.AddWithValue("@PhoneNo", newSeller.PhoneNo);
                command.Parameters.AddWithValue("@Address", newSeller.Address);
                int stateId=getStateId(newSeller.StateName);
                int cityId = getCityId(newSeller.CityName);
                command.Parameters.AddWithValue("@StateId",stateId);
                command.Parameters.AddWithValue("@CityId", cityId);
                command.Parameters.AddWithValue("@EmailId", newSeller.EmailId);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                SellerAdded = true;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return SellerAdded;
        }

        //public List<Seller> GetAllSellersDAL()
        //{
        //    List<Seller> SellerList = new List<Seller>();
        //    string Query = "EHS.GetSeller";
        //    SqlCommand command = new SqlCommand(Query, connection);
        //    command.CommandType = CommandType.StoredProcedure;
        //    connection.Open();
        //    SqlDataReader Reader = command.ExecuteReader();
        //    if (Reader.HasRows)
        //    {
        //        while (Reader.Read())
        //        {
        //            Seller s = new Seller();
        //            s.SellerId = int.Parse(Reader[0].ToString());
        //            s.UserName = Reader[1].ToString();
        //            s.FirstName = Reader[2].ToString();
        //            s.LastName = Reader[3].ToString();                  
        //            s.DateofBirth = DateTime.Parse( Reader[4].ToString());
        //            s.PhoneNo = long.Parse(Reader[5].ToString());
        //            s.Address = Reader[6].ToString();
        //            //s.StateId = int.Parse(Reader[7].ToString());
        //            //s.CityId = int.Parse(Reader[8].ToString());
        //            s.EmailId = Reader[9].ToString();
        //            SellerList.Add(s);
        //        }
        //    }
        //    connection.Close();
        //    return SellerList;

        //}

        //public bool getSellerPassword(Seller seller)
        //{
        //    bool IsPasswordMatch = false;
        //    try
        //    {
        //        SqlCommand command = new SqlCommand();
        //        // command.CommandText = "select password from Users_166026 where username=@username and usertype=@usertype";
        //        command.CommandText = "EHS.GetPassword";
        //        command.Parameters.AddWithValue("@username", seller.UserName);
        //        command.Parameters.AddWithValue("@usertype", seller.);
        //        command.Connection = connection;
        //        connection.Open();
        //        object retrievePassword = command.ExecuteScalar().ToString();
        //        IsPasswordMatch = false;
        //        if (retrievePassword != null && seller.Password == retrievePassword.ToString())
        //        {
        //            IsPasswordMatch = true;
        //        }
        //    }
        //    catch (SqlException Exception)
        //    {

        //    }
        //    catch (UserRegistrationException Exception)
        //    {

        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return IsPasswordMatch;
        //}
    }
}
